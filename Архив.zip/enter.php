<!doctype html>
<html>
<head>

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=1280">
  <meta charset="utf-8">
  <title>Заголовок</title>

  <!-- При повторных загрузках шрифты у нас в кэше. Подключаем их из кэша в самом начале, чтобы страница отобразилась нужным шрифтом сразу -->
  <script src="statics/js/cached-fonts.js"></script>
  <link rel="stylesheet" href="statics/css/style.css">
  <link rel="stylesheet" href="statics/css/jquery.bxslider.css">
  <script>
    // Сообщение об ошибке при аякс запросе. Можно сделать, чтобы пользователь написал там что-то с помощью какого-нибудь Висивига
    var DEFAULT_AJAX_ERROR_MESS = '<h2>Ошибка</h2><p>Не удалось загрузить данные. Попробуйте перезагрузить страницу и повторить запрос немного позже.</p>';
  </script>

</head>
<body id="page-enter">


  <div id="wrapper">
    <div id="wrapper-inner">
      <?php include __DIR__ . '/chunks/blocks/header.inc' ?>
      <?php include __DIR__ . '/chunks/pages/enter.inc' ?>
      <?php include __DIR__ . '/chunks/blocks/footer.inc' ?>
    </div>
  </div>

  <?php include __DIR__ . '/chunks/blocks/popups.inc' ?>


  <script src="statics/lib/jquery_v2.js"></script>
  <script src="statics/lib/jquery.bxslider.min.js"></script>
  <script src="statics/js/script.js"></script>

  <!-- При первой загрузке шрифты подгружаются в самом конце, так как весят прилично -->
  <script src="statics/js/load-fonts.js"></script>
</body>
</html>

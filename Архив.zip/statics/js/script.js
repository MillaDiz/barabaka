var g = Object.create(null);
(function() {
  /*jshint validthis:true */
  'use strict';



// КЭШ
  g.pops = document.getElementById('popups');
  g.pops.style.display = 'none';
  g.wr = document.getElementById('wrapper');
  g.wrI = document.getElementById('wrapper-inner');
  g.h = document.querySelector('header');
  g.n = document.querySelector('header');

  // для экземпляров Popup и FullwindowPopup
  g.popups = {};



/* ФУНКЦИИ И КЛАССЫ */
// эмуляция плэйсхолдеров
  g.emulatePlaceholder = function() {
    var input = this.querySelector('input') || this.querySelector('textarea'),
        ph = this.querySelector('._js_placeholder-emu_placeholder');

    if ( input.value ) ph.classList.add('_js_placeholder-emu_focused');

    input.addEventListener('focus', function() {
      ph.classList.add('_js_placeholder-emu_focused');
    });

    input.addEventListener('blur', function() {
      if ( !this.value ) ph.classList.remove('_js_placeholder-emu_focused');
    });
  };


  (function() {
    var inputGroups = document.querySelectorAll('._js_placeholder-emu'),
        i;

    for (i = inputGroups.length; i--;) {
      g.emulatePlaceholder.call(inputGroups[i]);
    }
  })();



// эмуляция background-image:cover для картинок
  g.emulateBGCoverForImg = function() {
    var parent = this.parentNode,
        pW = parent.clientWidth,
        pH = parent.clientHeight,
        pRatio = pW / pH,
        imgW = this.naturalWidth,
        imgH = this.naturalHeight,
        imgRatio = imgW / imgH,
        imgCalcW, imgCalcH;

    this.style.top = '';
    this.style.left = '';
    this.style.width = '';
    this.style.height = '';

    if (imgRatio > pRatio) {

      this.style.height = pH + 'px';
      imgCalcW = this.clientWidth;
      this.style.left = -(imgCalcW - pW) / 2 + 'px';

    } else if (imgRatio < pRatio) {

      this.style.width = pW + 'px';
      imgCalcH = this.clientHeight;
      this.style.top = -(imgCalcH - pH) / 2 + 'px';

    } else {

      this.style.width = pW + 'px';
      this.style.height = pH + 'px';

    }
  };


  (function() {
    var imgs = document.querySelectorAll('._js_cover-emu > img'),
    i;

    if (!imgs.length) return;

    for (i = imgs.length; i--;) {
      g.emulateBGCoverForImg.call(imgs[i]);
      imgs[i].addEventListener('load', g.emulateBGCoverForImg);
    }

    window.addEventListener('resize', function() {
      for (i = imgs.length; i--;) {
        g.emulateBGCoverForImg.call(imgs[i]);
      }
    });
  })();



// Попапы
  function Popup(options) {
    this._st = Object.create(null);
    this._op = Object.create(null);
    this._op.popupId = Popup._st.idCounter++;

    this.popup = options.popup || null;

    this._op.afterAjaxComplete        = options.afterAjaxComplete       || null;
    this._op.afterHide                = options.afterHide               || null;
    this._op.afterShow                = options.afterShow               || null;
    this._op.ajaxErrorHTML            = options.ajaxErrorHTML           || Popup.ajaxErrorHTML;
    this._op.animationTime            = options.animationTime           || 250;
    this._op.beforeHide               = options.beforeHide              || null;
    this._op.beforeShow               = options.beforeShow              || null;
    this._op.callers                  = options.callers                 || null;
    this._op.classList                = options.classList               || '';
    this._op.closeOnScroll            = options.closeOnScroll           || false;
    this._op.closers                  = options.closers                 || null;
    this._op.dontCloseOnOutsideClick  = options.dontCloseOnOutsideClick || false;
    this._op.href                     = options.href                    || null;
    this._op.id                       = options.id                      || false;
    this._op.parent                   = options.parent                  || null;

    this._init();
  }

  g.Popup = Popup;


  Popup._st = {
    idCounter: 0
  };


  Popup.ajaxErrorHTML = '<div class="__user-input">' + DEFAULT_AJAX_ERROR_MESS + '</div>';


  Popup.prototype._init = function() {
    var t = this,
        i;

    if ( !t.popup ) {
      if ( t._op.id && document.getElementById(t._op.id) ) return console.error('DOM element with id="' + t._op.id + '" already exists.');
      t._createPopupWithAJAXContent();
    }

    if ( getComputedStyle(t.popup).display == 'none' ) {
      t._st.isOpen = false;
    } else {
      t._st.isOpen = true;
    }

    t._st.inProgress = false;

    t.showPopup = t.showPopup.bind(t);
    t.hidePopup = t.hidePopup.bind(t);

    if ( t._op.callers ) {
      if ( t._op.callers.length !== undefined ) {
        for ( i = t._op.callers.length; i--; ) t._op.callers[i].addEventListener('click', showPopup);
      } else {
        t._op.callers.addEventListener('click', showPopup);
      }
    }

    if ( t._op.closers ) {
      if ( t._op.closers.length !== undefined ) {
        for ( i = t._op.closers.length; i--; ) t._op.closers[i].addEventListener('click', hidePopup);
      } else {
        t._op.closers.addEventListener('click', hidePopup);
      }
    }

    if (t._op.closeOnScroll) {
      window.addEventListener('scroll', function(e) {
        if ( !t._st.isOpen || t._st.inProgress ) return;
        t.hidePopup();
      });
    }

    if (t._op.dontCloseOnOutsideClick) return;

    document.addEventListener('click', function(e) {
      if ( !t._st.isOpen || t._st.inProgress ) return;

      var el = e.target;

      while (el.nodeType == 1) {
        if ( t.popup == el ) return;
        el = el.parentNode;
      }

      t.hidePopup();
    });


    function showPopup(e) {
      this.blur();
      e.preventDefault();
      t.showPopup();
    }


    function hidePopup(e) {
      e.preventDefault();
      t.hidePopup();
    }
  };


  Popup.prototype._createPopupWithAJAXContent = function() {
    var id = this._op.id ? this._op.id : '_js_popup-id-' + this._op.popupId,
        classList = '_js_popup _js_popup_loading';

    this.popup = document.createElement('div');

    if (this._op.classList) classList += ' ' + this._op.classList;

    this.popup.id = id;
    this.popup.className = classList;
    this.popup.style.display = 'none';
    this._op.parent.appendChild( this.popup );

    this._st.notInitialized = true;
  };


  Popup.prototype._loadPopupContent = function() {
    var t = this;

    t._st.notInitialized = false;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', t._op.href, true);

    xhr.onreadystatechange = function() { // (3)
      if (xhr.readyState != 4) return;

      if ( xhr.status >= 200 && xhr.status < 400 ) {
        insertDataIntoPopup(xhr.responseText);
      } else {
        insertDataIntoPopup(t._op.ajaxErrorHTML);
      }
    };

    xhr.send();


    function insertDataIntoPopup(res) {
      t.popup.innerHTML = res;
      t.popup.classList.remove('_js_popup_loading');
      if (t._op.afterAjaxComplete) t._op.afterAjaxComplete.call(t, xhr.status);
    }
  };


  Popup.prototype.showPopup = function() {
    var t = this,
        callbackRetValue;

    if ( t._st.inProgress || t._st.isOpen ) return;
    t._st.inProgress = true;

    if ( t._op.beforeShow && !t._st.cancelBeforeShow ) {
      callbackRetValue = t._op.beforeShow.call(t);

      if (callbackRetValue === false) {
        t._st.inProgress = false;
        return;
      }
    }

    t.popup.style.display = 'block';
    t.popup.offsetHeight;
    t.popup.classList.add('_js_popup_active');

    if (t._st.notInitialized) t._loadPopupContent();


    setTimeout(function() {
      if ( t._op.afterShow ) t._op.afterShow.call(t);

      t._st.isOpen = true;
      t._st.inProgress = false;
    }, t._op.animationTime);
  };


  Popup.prototype.hidePopup = function() {
    var t = this,
        callbackRetValue;

    if ( t._st.inProgress || !t._st.isOpen ) return;
    t._st.inProgress = true;

    if ( t._op.beforeHide && !t._st.cancelBeforeHide ) {
      callbackRetValue = t._op.beforeHide.call(t);

      if (callbackRetValue === false) {
        t._st.inProgress = false;
        return;
      }
    }

    t.popup.classList.remove('_js_popup_active');


    setTimeout(function() {
      t.popup.style.display = 'none';

      if ( t._op.afterHide ) t._op.afterHide.call(t);

      t._st.isOpen = false;
      t._st.inProgress = false;
    }, t._op.animationTime);
  };


  Popup.prototype.isOpen = function() {
    return this._st.isOpen;
  };


  Popup.prototype.isInProgress = function() {
    return this._st.inProgress;
  };



// Надстройка для Popup - попапы на весь экран с системным скролом.
  function FullwindowPopup(options) {
    var defAfterShow = options.afterShow,
        defAfterHide = options.afterHide,
        clonedOptions = Object.create(options),
        tabIndexedEls = [];

    if ( options.popup ) {
      options.popup.style.display = 'none';
    } else {
      clonedOptions.parent = g.pops;
    }

    Popup.call(this, clonedOptions);


    Array.prototype.forEach.call(this.popup.querySelectorAll('*[data-tabindex]'), function(el) {
      tabIndexedEls.push(el);
    });

    this._st.tabIndexedEls = tabIndexedEls.sort(function(a, b) {
      var aInd = +a.getAttribute('data-tabindex'),
          bInd = +b.getAttribute('data-tabindex');
      return aInd > bInd;
    });

    this._st.tabIndex = 0;


    this._st.cancelBeforeHide = true;
    this._st.cancelBeforeShow = true;

    this._keyPressHandler = this._keyPressHandler.bind(this);
    this._op.dontCloseOnEscape = options.dontCloseOnEscape || false;

    if ( options.valignMiddle ) {
      this._op.valignMiddle = true;
      this.valignMiddle = this.valignMiddle.bind(this);
    }

    this._op.afterShow = function() {
      if (defAfterShow) defAfterShow.call(this);

      FullwindowPopup._st.shown = this;
      FullwindowPopup._st.inProgress = false;
    };

    this._op.afterHide = function() {
      if ( this._op.valignMiddle ) {
        window.removeEventListener('resize', this.valignMiddle);
        window.removeEventListener('keydown', this._keyPressHandler);
        this._st.tabIndex = 0;
        this.popup.style.marginTop = '';
      }

      if ( FullwindowPopup._st.switchingTo ) {
        if (defAfterHide) defAfterHide.call(this);
        FullwindowPopup._st.switchingTo._continueShowing();
        FullwindowPopup._st.switchingTo = null;
        return;
      }

      g.pops.style.display = 'none';
      g.wrI.style.top = '';
      g.wr.classList.remove('_js_popup_wrapper-clipped');
      window.scrollTo(0, FullwindowPopup._st.savedScroll);
      FullwindowPopup._st.savedScroll = 0;

      if (defAfterHide) defAfterHide.call(this);

      FullwindowPopup._st.shown = null;
      FullwindowPopup._st.inProgress = false;
    };
  }

  g.FullwindowPopup = FullwindowPopup;
  FullwindowPopup.prototype = Object.create( Popup.prototype );
  FullwindowPopup.prototype.constructor = FullwindowPopup;


  FullwindowPopup._st = {
    inProgress: false,
    savedScroll: 0,
    shown: null,
    switchingTo: null
  };


  FullwindowPopup.closeShown = function() {
    var shown = FullwindowPopup._st.shown;
    if (shown) FullwindowPopup._st.shown.hidePopup();
  };


  FullwindowPopup.getShown = function() {
    var shown = FullwindowPopup._st.shown;
    if ( shown ) return shown;
    return false;
  };


  FullwindowPopup.isInProgress = function() {
    return FullwindowPopup._st.inProgress;
  };


  FullwindowPopup.prototype._valignMiddleBeforeShow = function() {
    var popsSty = getComputedStyle(g.pops),
        wH = document.documentElement.clientHeight - ( parseInt( popsSty.paddingTop ) + parseInt( popsSty.paddingBottom ) ),
        height;

    this.popup.style.display = 'block';
    this.popup.style.position = 'absolute';
    this.popup.style.visibility = 'hidden';

    height = this.popup.offsetHeight;

    this.popup.style.display = '';
    this.popup.style.position = '';
    this.popup.style.visibility = '';

    if (height < wH) this.popup.style.marginTop = (wH - height) / 2 + 'px';
  };


  FullwindowPopup.prototype.valignMiddle = function() {
    var popsSty = getComputedStyle(g.pops),
        wH = document.documentElement.clientHeight - ( parseInt( popsSty.paddingTop ) + parseInt( popsSty.paddingBottom ) ),
        height = this.popup.offsetHeight;

    if (height < wH)  this.popup.style.marginTop = (wH - height) / 2 + 'px';
    else              this.popup.style.marginTop = '';
  };


  FullwindowPopup.prototype.showPopup = function() {
    var toHide = FullwindowPopup._st.shown,
        callbackRetValue;

    if ( FullwindowPopup._st.inProgress || this._st.isOpen ) return;
    FullwindowPopup._st.inProgress = true;

    if ( toHide && toHide._op.beforeHide ) {
      callbackRetValue = toHide._op.beforeHide.call(toHide);

      if (callbackRetValue === false) {
        FullwindowPopup._st.inProgress = false;
        return;
      }
    }

    if ( this._op.beforeShow ) {
      callbackRetValue = this._op.beforeShow.call(this);

      if (callbackRetValue === false) {
        FullwindowPopup._st.inProgress = false;
        return;
      }
    }

    if (toHide) {
      this._hideShown();
      return;
    }

    FullwindowPopup._st.savedScroll = window.pageYOffset;
    g.wr.classList.add('_js_popup_wrapper-clipped');
    g.wrI.style.top = -FullwindowPopup._st.savedScroll + 'px';

    window.scrollTo(0, 0);

    g.pops.style.display = 'block';
    g.pops.offsetHeight;
    g.pops.classList.add('_js_popup_active');
    this._continueShowing();
  };


  FullwindowPopup.prototype.hidePopup = function() {
    var callbackRetValue;

    if ( FullwindowPopup._st.inProgress || !this._st.isOpen ) return;
    FullwindowPopup._st.inProgress = true;

    if ( this._op.beforeHide ) {
      callbackRetValue = this._op.beforeHide.call(this);

      if (callbackRetValue === false) {
        FullwindowPopup._st.inProgress = false;
        return;
      }
    }

    g.pops.classList.remove('_js_popup_active');
    Popup.prototype.hidePopup.call(this);
  };


  FullwindowPopup.prototype._continueShowing = function() {
    var defAfterAjaxComplete;

    if (this._op.valignMiddle) {
      this._valignMiddleBeforeShow();
      window.addEventListener('resize', this.valignMiddle);
      window.addEventListener('keydown', this._keyPressHandler);

      if (this._op.href) {
        defAfterAjaxComplete = this._op.afterAjaxComplete;

        this._op.afterAjaxComplete = function(xhrStatus) {
          this.valignMiddle();
          if (defAfterAjaxComplete) defAfterAjaxComplete.call(this, xhrStatus);
        };
      }
    }

    Popup.prototype.showPopup.call(this);
  };


  FullwindowPopup.prototype._hideShown = function() {
    FullwindowPopup._st.switchingTo = this;
    Popup.prototype.hidePopup.call(FullwindowPopup._st.shown);
  };


  FullwindowPopup.prototype._keyPressHandler = function(e) {
    var indexesToSkip;

    if ( e.keyCode == 27 && !this._op.dontCloseOnEscape ) {
      e.preventDefault();
      this.hidePopup();
      return;
    }

    if ( e.keyCode == 9 ) {
      e.preventDefault();

      if (!this._st.tabIndexedEls.length) return;

      indexesToSkip = [];
      g.each.call(this._st.tabIndexedEls, function(el, i) {
        if (!el.offsetHeight) indexesToSkip.push(i);
      });

      if (this._st.tabIndexedEls.length == indexesToSkip.length) return;

      while( ~indexesToSkip.indexOf( this._st.tabIndex ) ) {
        this._st.tabIndex++;
        if ( this._st.tabIndex >= this._st.tabIndexedEls.length ) this._st.tabIndex = 0;
      }

      this._st.tabIndexedEls[ this._st.tabIndex++ ].focus();
      if ( this._st.tabIndex >= this._st.tabIndexedEls.length ) this._st.tabIndex = 0;
    }
  };



/* КОД */
// media mode
  (function() {
    var mt = document.createElement('div');
    mt.id = 'media-test';
    document.body.appendChild(mt);

    calcMediaMode();
    window.addEventListener('resize', calcMediaMode);


    function calcMediaMode() {
      g.mediaMode = +getComputedStyle(mt).zIndex;
    }
  })();



// увеличение дефолтного значения padding-bottom у #wrapper-inner, если высота футера его превысит
  (function() {
    var footer = document.querySelector('footer');

    fixWrapperInnerPaddingBottom();
    window.addEventListener('load', fixWrapperInnerPaddingBottom);
    window.addEventListener('resize', fixWrapperInnerPaddingBottom);


    function fixWrapperInnerPaddingBottom() {
      var fH = footer.offsetHeight;
      g.wrI.style.paddingBottom = '';
      if ( fH > parseInt( getComputedStyle(g.wrI).paddingBottom ) ) g.wrI.style.paddingBottom = fH + 'px';
    }

    g.fixWrapperInnerPaddingBottom = fixWrapperInnerPaddingBottom;
  })();



// диалоговые попапы
  (function() {
    var popup = document.getElementById('dialog-popup'),
        message = document.getElementById('dialog-popup-message'),
        textarea = document.getElementById('dialog-popup-textarea'),
        ok = document.getElementById('dialog-popup-ok'),
        cancel = document.getElementById('dialog-popup-cancel'),
        okToFocus = false,
        callback;

    g.popups['dialog-popup'] = new FullwindowPopup({
      popup: popup,
      closers: popup.querySelectorAll('._js_popup-closer, #dialog-popup-cancel'),
      valignMiddle: true,

      afterShow: function() {
        if (okToFocus) {
          ok.focus();
          this.tabIndex = 2;
        } else {
          cancel.focus();
          this.tabIndex = 0;
        }
      },

      afterHide: function() {
        callback = null;
        okToFocus = false;
        cancel.classList.remove('_js_active');
        textarea.classList.remove('_js_active');
      }
    });

    ok.addEventListener('click', function(e) {
      e.preventDefault();
      if (typeof callback == 'function') callback();
      g.popups['dialog-popup'].hidePopup();
    });


    g.alert = function(html) {
      if (html) message.innerHTML = html;
      g.popups['dialog-popup'].showPopup();
      okToFocus = true;
    };


    g.confirm = function(html, cb) {
      if (html) message.innerHTML = html;
      cancel.classList.add('_js_active');
      callback = cb;
      g.popups['dialog-popup'].showPopup();
    };


    g.prompt = function(html, cb) {
      if (html) message.innerHTML = html;
      textarea.classList.add('_js_active');
      cancel.classList.add('_js_active');
      callback = cb;
      g.popups['dialog-popup'].showPopup();
    };
  })();



// обработчики для прокрутки
  (function() {
    var headerHeight = 0;
    //     gotopBut = document.getElementById('gotop');

    // window.addEventListener('load', calcHeaderHeight);
    // window.addEventListener('resize', calcHeaderHeight);

    window.addEventListener('scroll', onScrollHandler);


    // function calcHeaderHeight() {
    //   headerHeight = g.h.offsetHeight;
    // }


    function onScrollHandler() {
      // if ( FullwindowPopup.getShown() || FullwindowPopup.isInProgress() ) return;

      if ( window.pageYOffset > headerHeight && !g.n.classList.contains('_js_sticky') ) {
        g.n.classList.add('_js_sticky');
        // gotopBut.classList.add('_js_active');
      } else if ( window.pageYOffset <= headerHeight && g.n.classList.contains('_js_sticky') ) {
        g.n.classList.remove('_js_sticky');
        // gotopBut.classList.remove('_js_active');
      }
    }
  })();


//
  $(function() {

    var $slider = $('.bxslider-main');
    if ( !$slider ) return;

    $slider.bxSlider({
      controls: false
    });
  });

  $(function() {

    var $slider = $('.bxslider-quests');
    if ( !$slider ) return;

    $slider.bxSlider({
      controls: true,
      pager: false
    });
  });


// Корректировка высоты для пропорциональности
$(function() {
  var $block = $('.q50'),
      $k = 720/310;

  fixHeight();
  $(window).resize(fixHeight);

  function fixHeight() {
    var h = $block.outerHeight($block.outerWidth() / $k);
  };
});


// Скрытие-показ квестов в контактах
$(function() {
  var $tables = $('.address-inner').find('.address-show-content'),
      $callers = $('.address-inner').find('.address-show-caller'),
      $wrapM = $('._js_height_map'),
      $mH = $('.map'),
      $wrapMH;


  updateHeightMap();

  function updateHeightMap() {
    $wrapMH = $wrapM.height();
    $mH.css('height', $wrapMH);
  };


  $('.address-inner').each(function(i) {
    $(this).find('.address-show-caller').bind('click', function() {

      var $this = $(this);

      var $table = $('.address-show-content').eq(i),
          $hT = $table.find('table').outerHeight(),
          $padT = parseFloat($table.find('table').css('marginBottom')),
          $hC = $table.find('.contacts-inner').outerHeight(),
          $hRes = $hT + $padT + $hC;

          console.log($('._js_height_map').height());

      if( $table.hasClass('visible') ) {
        $this.removeClass('active');
        $table.css('height', '');
        $table.removeClass('visible');
      } else {
        $callers.removeClass('active');
        $this.addClass('active');
        $tables.removeClass('visible');
        $tables.css('height', '');
        $table.fadeIn(0).addClass('visible');
        $table.css('height', $hRes);
      }
    });
  });
});



  // Selemu
  window.addEventListener('load', function() {
    var selects = document.querySelectorAll('div._js_selemu1');

    Array.prototype.forEach.call(selects, function(select) {
      // эта функция будет запущена для каждого ._js_selemu1 элемента на странице
      // здесь переменная select - это один из ._js_selemu1 элементов

      // ищем внутри текущего ._js_selemu1 элемента:
      var caller = select.querySelector('button._js_characteristics-popup-caller'),
          dd = select.querySelector('div.characteristics-popup'),
          inner = dd.querySelector('div.characteristics-popup-inner'),
          options = inner.querySelectorAll('button'),

          // тут будет храниться индекс кнопки из списка, по которой кликнули
          selectedInd = 0;

      var selemu = new g.Popup({
        popup: dd,
        callers: caller,
        // animationTime: 50,

        beforeShow: function() {
          // плавное увеличение по высоте

          setTimeout(function() {
            // caller.classList.add('active');
              $('.scrollbar-inner').scrollbar();
            dd.style.height = inner.offsetHeight + 'px';
          }, 0);
        },

        beforeHide: function() {
          // caller.classList.remove('active');
          dd.style.height = '';
        },

        afterHide: function() {
          // убираем класс активности (который скрывает элемент) у прошлой кнопки
          var activeButton = inner.querySelector('button._js_active');
          if (activeButton) activeButton.classList.remove('_js_active');

          // добавляем класс активности для кликнутой кнопке (узнаем ее по индексу)
          options[selectedInd].classList.add('_js_active');
        }
      });


      // выбор
      Array.prototype.forEach.call(options, function(option, i) {
        // эта функция будет запущена для каждой кнопки из списка
        // здесь переменная option - это одна из кнопок, а i - её индек

        // клик по кнопке из списка
        option.addEventListener('click', function() {

          // document.querySelectorAll('._js_characteristics-popup-caller').classList.add('selected');
          // меняем текст в открывалке
          caller.textContent = this.textContent;

          caller.classList.add('_js_selected'); // Поставить класс

          // сохраняем индекс, чтобы после скрытия попапа навесить сюда класс
          selectedInd = i;
          // скрываем попап
          selemu.hidePopup();
        });
      });
    });
  });



  // Корзина - оформить заказ
  $(function() {
    var $caller = $('._js_order-caller'),
        $block = $('._js_order-show'),
        $wrapper = $('.make-out-inner');

    $caller.bind('click', function() {
      var $wH = $wrapper.outerHeight();

      console.log($wH);
      $block.css('height', $wH + 5).addClass('show');
    });
  })


  // Фанси
  $(function() {
    var $fancybox = $('.fancybox'),
        savedScroll = 0,
        isShown = false;

    if (!$fancybox.fancybox ) return;
    $fancybox.fancybox({
      width: 1200,
      height: 800,
      maxWidth: '80%',
      maxHeight: '90%',
      padding: 0,

      beforeShow: function() {
        if (isShown) return;
        savedScroll = window.pageYOffset;
        // FullwindowPopup._st.wr.addClass('_js_popup_wrapper-clipped');
        // FullwindowPopup._st.wrI.css('top', -savedScroll);

        g.wr.classList.add('_js_popup_wrapper-clipped');
        g.wrI.style.top = -FullwindowPopup._st.savedScroll + 'px';
        isShown = true;
      },
      afterClose: function() {
        // FullwindowPopup._st.wrI.css('top', '');
        // FullwindowPopup._st.wr.removeClass('_js_popup_wrapper-clipped');

        g.wrI.style.top = '';
        g.wr.classList.remove('_js_popup_wrapper-clipped');
        window.scrollTo(0, savedScroll);
        isShown = false;
      }
    });
  });





})();

(function() {
  var style;

  if ( !localStorage.barabaka ) return;

  style = document.createElement('style');
  style.textContent = localStorage.barabaka;
  document.head.appendChild(style);
})();

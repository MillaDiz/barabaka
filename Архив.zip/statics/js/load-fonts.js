(function() {
  var req, style;

  if (localStorage.barabaka) return;

  req = new XMLHttpRequest();
  req.open('GET', 'statics/css/fonts.css', true);

  req.onload = function() {
    if (req.status < 200 && req.status >= 400) return;

    localStorage.barabaka = req.responseText;

    style = document.createElement('style');
    style.textContent = localStorage.barabaka;
    document.head.appendChild(style);
  };

  req.send();
})();

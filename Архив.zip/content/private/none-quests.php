<div class="user-quests">
	<div class="none-quests">
		<h2>К сожалению, у вас нет забронированных квестов.</h2>
		<button class="c_but"><span>Перейти в каталог</span></button>
	</div>
</div>
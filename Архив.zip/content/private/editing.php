<div class="user-info-editing">
	<div class="wrapper-image">
		<label><input type="file"><img src="content/img/users/root-big.jpg" alt=""><p>Загрузить фотографию</p></label>
	</div>

	<div class="user-info-inner">
		<div class="user-info-inner1">
			<h3>Личная информация</h3>

			<div class="wrapper-data">
				<div class="data name">
					<p>ФИО</p>
					<p><input type="text" value="Василиса Премудрая"></p>
					<p><button class="c_but"><span>Сохранить</span></button><button class="c_but_t">Отменить</button></p>
				</div>
				<div class="data birth">
					<p>Дата рождения</p>
					<div class="_js_selemu1">
	          <button class="_js_characteristics-popup-caller">Число</button>
	          <div class="characteristics-popup">
	            <div class="characteristics-popup-inner scrollbar-inner">
	              <button>1</button>
	              <button>2</button>
	              <button>3</button>
	              <button>4</button>
	             	<button>5</button>
	              <button>6</button>
	              <button>7</button>
	              <button>8</button>
	             	<button>9</button>
	              <button>10</button>
	              <button>11</button>
	              <button>12</button>
	             	<button>13</button>
	              <button>14</button>
	              <button>15</button>
	              <button>16</button>
	             	<button>17</button>
	              <button>18</button>
	              <button>19</button>
	              <button>20</button>
	             	<button>21</button>
	             	<button>22</button>
	              <button>23</button>
	              <button>24</button>
	              <button>25</button>
	             	<button>26</button>
	              <button>27</button>
	              <button>28</button>
	              <button>29</button>
	             	<button>30</button>
	              <button>31</button>
	            </div>
	          </div>
	        </div>
	        <div class="_js_selemu1">
	          <button class="_js_characteristics-popup-caller">Месяц</button>
	          <div class="characteristics-popup">
	            <div class="characteristics-popup-inner scrollbar-inner">
	              <button>Январь</button>
	              <button>Февраль</button>
	              <button>Март</button>
	              <button>Апрель</button>
	              <button>Май</button>
	              <button>Июнь</button>
	              <button>Июль</button>
	              <button>Август</button>
	              <button>Сентябрь</button>
	              <button>Октябрь</button>
	              <button>Ноябрь</button>
	              <button>Декабрь</button>
	            </div>
	          </div>
	        </div>
	        <div class="_js_selemu1">
	          <button class="_js_characteristics-popup-caller">Год</button>
	          <div class="characteristics-popup">
	            <div class="characteristics-popup-inner scrollbar-inner">
	              <button>1900</button>
	              <button>1910</button>
	              <button>1920</button>
	              <button>1930</button>
	              <button>1940</button>
	              <button>1950</button>
	              <button>1960</button>
	              <button>1970</button>
	              <button>1980</button>
	              <button>1990</button>
	              <button>2000</button>
	              <button>2010</button>
	              <button>2020</button>
	              <button>2030</button>
	              <button>2040</button>
	              <button>2050</button>
	            </div>
	          </div>
	        </div>
				</div>
				<div class="data sex">
					<p>Пол</p>
					 <div class="_js_selemu1">
	          <button class="_js_characteristics-popup-caller">Мужской</button>
	          <div class="characteristics-popup">
	            <div class="characteristics-popup-inner">
	              <button class="_js_active">Мужской</button>
	              <button>Женский</button>
	            </div>
	          </div>
	        </div>
				</div>
				<div class="data">
					<p>Местоположение</p>
					<p><input type="text" value="Санкт-Петербург, Россия"></p>
				</div>
				<div class="data">
					<p>E-mail</p>
					<p><input type="text" value="vasilisa@mail.ru"></p>
				</div>
				<div class="data">
					<p>Номер телефона</p>
					<p><input type="text" placeholder="не указан"></p>
				</div>
			</div>

			<div class="wrapper-checkbox">
				<div>
					<input type="checkbox" id="check1"><label for="check1"></label><label for="check1">Получать письма о новых квестах</label>
				</div>
				<div>
					<input type="checkbox" id="check2"><label for="check2"></label><label for="check2">Получать сервисные SMS</label>
				</div>
				<div>
					<input type="checkbox" id="check3"><label for="check3"></label><label for="check3">Получать оповещения на E-mail</label>
				</div>
			</div>
		</div>

		<div class="user-info-inner2">
			<h3>Социальные сети</h3>

			<p>Вы можете привязать ваши аккаунты в социальных сетях и авторизовываться через них.</p>
			<ul class="social">
				<li><input type="checkbox" id="social0"><label for="social0"></label><label for="social0">В контакте</label></li>
				<li><input type="checkbox" id="social1"><label for="social1"></label><label for="social1">Factbook</label></li>
				<li><input type="checkbox" id="social2"><label for="social2"></label><label for="social2">Twitter</label></li>
				<li><input type="checkbox" id="social3"><label for="social3"></label><label for="social3">Одноклассники</label></li>
			</ul>
		</div>
	</div>
</div>
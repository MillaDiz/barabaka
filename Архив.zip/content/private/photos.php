<div class="user-photos">

	<?php $quests = array(
    'q1',
    'q2'
  ) ?>

  <?php for ($i = 0; $i < 2; $i++): ?>
		<div class="quest <?php echo $quests[$i]; ?>">
			<h2>7 загадок фараона</h2>
			<div class="wrapper-photos">
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-0-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-0.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-1-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-1.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-2-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-2.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-3-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-3.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-4-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-4.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-5-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-5.jpg" alt=""></a>
				<a class="fancybox" rel="group" href="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-6-big.jpg"><img src="content/img/quests/q<?php echo $i ?>/q<?php echo $i ?>-6.jpg" alt=""></a>
			</div>
		</div>
	<?php endfor ?>
</div>
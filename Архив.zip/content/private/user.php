<div class="user-info">
	<div class="wrapper-image">
		<a href=""><img src="content/img/users/root-big.jpg" alt=""></a>
	</div>

	<div class="user-info-inner">
		<div class="user-info-inner1">
			<h3>Личная информация</h3>

			<div class="wrapper-data">
				<div class="data">
					<p>ФИО</p>
					<p><input type="text" value="Василиса Премудрая"></p>
				</div>
				<div class="data">
					<p>Дата рождения</p>
					<p><input type="text" value="3 января 1540"></p>
				</div>
				<div class="data">
					<p>Пол</p>
					<p><input type="text" value="Женский"></p>
				</div>
				<div class="data">
					<p>Местоположение</p>
					<p><input type="text" value="Санкт-Петербург, Россия"></p>
				</div>
				<div class="data">
					<p>E-mail</p>
					<p><input type="text" value="vasilisa@mail.ru"></p>
				</div>
				<div class="data">
					<p>Номер телефона</p>
					<p><input type="text" placeholder="не указан"></p>
				</div>
			</div>

			<div class="wrapper-checkbox">
				<div>
					<input type="checkbox" id="check1"><label for="check1"></label><label for="check1">Получать письма о новых квестах</label>
				</div>
				<div>
					<input type="checkbox" id="check2"><label for="check2"></label><label for="check2">Получать сервисные SMS</label>
				</div>
				<div>
					<input type="checkbox" id="check3"><label for="check3"></label><label for="check3">Получать оповещения на E-mail</label>
				</div>
			</div>
		</div>

		<div class="user-info-inner2">
			<h3>Социальные сети</h3>

			<p>Вы можете привязать ваши аккаунты в социальных сетях и авторизовываться через них.</p>
			<ul class="social">
				<li><input type="checkbox" id="social0"><label for="social0"></label><label for="social0">В контакте</label></li>
				<li><input type="checkbox" id="social1"><label for="social1"></label><label for="social1">Factbook</label></li>
				<li><input type="checkbox" id="social2"><label for="social2"></label><label for="social2">Twitter</label></li>
				<li><input type="checkbox" id="social3"><label for="social3"></label><label for="social3">Одноклассники</label></li>
			</ul>
		</div>
	</div>
</div>
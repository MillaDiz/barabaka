<div class="user-quests">
	
	<?php $quests = array(
    '',
    '',
    'complete',
    'no-begin'
  ) ?>

	<?php for ($i = 0; $i < 4; $i++): ?>

		<div class="quest <?php echo $quests[$i] ?>">
			<div class="name">
				<h2>7 загадок фараона</h2>
			</div>
			<div class="address">
				<p>Москва, пр-т Мира, 79</p>
				<p>(вход с ул. Гиляровского)</p>
				<div>
					<p><a href="tel:+74956660077">+7 (495) 666-00-77</a></p>
        	<p><a href="mailto:roman@barabaka.ru">roman@barabaka.ru</a></p>
				</div>
			</div>
			<div class="date">
				<p>24 января</p>
				<p>15:40</p>

			</div>
			<div class="cost">
				<p class="pay">4 5000 Р</p>
				<p class="method">(наличный, банковская карта)</p>
				<p class="complete">Пройден за 55 минут</p>
				<p class="no-begin">Не пройден</p>
				<div class="buttons">
					<button class="c_but"><span>Оплатить квест</span></button>
					<button class="c_but_t">Отменить бронь</button>
				</div>
				<div class="button">
					<button class="c_but"><span>Написать отзыв</span></button>
				</div>
			</div>
		</div>

	<?php endfor ?>
</div>